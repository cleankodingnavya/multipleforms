import React from 'react';
import Book from './components/Book';
import './App.css';

function App() {
  return (
    <div className="App">
      <Book/>
      
    </div>
  );
}

export default App;
